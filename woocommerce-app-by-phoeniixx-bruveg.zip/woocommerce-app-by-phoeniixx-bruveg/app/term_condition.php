<?php
    $data=get_option("phoen_term_condition_setting");
    if(empty($data)){
        $data=array("term_condition"=>"");
    }
?>